package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.ActivityLog
import com.example.model.AppUsage
import com.example.model.ChildDevice
import com.example.model.LogLevel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ParentalShieldUiState(
    val parentPin: String = "1234",
    val isParentAuthenticated: Boolean = false,
    val activeDeviceId: String = "device1",
    val emergencyContactPhone: String = "+1 (555) 911-2470",
    val isGlobalPanicActive: Boolean = false,
    val isSoundAlarmRinging: Boolean = false,
    val soundAlarmCountdown: Int = 10,
    val filterLogLevel: LogLevel? = null,
    val devices: List<ChildDevice> = emptyList(),
    val activityLogs: List<ActivityLog> = emptyList(),
    val userFeedbackMessage: String? = null
)

class ParentalShieldViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(
        ParentalShieldUiState(
            devices = listOf(
                ChildDevice(
                    id = "device1",
                    name = "Rahul (A34)",
                    model = "Samsung Galaxy A34",
                    age = 13,
                    iconType = "phone",
                    isOnline = true,
                    batteryPercent = 88,
                    isCharging = false,
                    lastSyncTime = "3 mins ago",
                    screenLocked = false,
                    youtubeBlocked = true,
                    playStoreBlocked = true,
                    callsBlocked = false,
                    wifiBlocked = false,
                    cameraBlocked = false,
                    gamesBlocked = true,
                    screenTimeLimitHours = 2.0f,
                    screenTimeUsedMinutes = 74,
                    bedtimeEnabled = true,
                    bedtimeStart = "21:30",
                    bedtimeEnd = "06:30",
                    studyModeActive = false,
                    currentLocation = "Lincoln High School - Safe Zone",
                    geofenceEnabled = true,
                    isInsideSafeZone = true,
                    webSafeSearchActive = true,
                    adultContentBlocked = true,
                    apps = listOf(
                        AppUsage("1", "YouTube", "com.google.android.youtube", "Streaming", 38, true),
                        AppUsage("2", "Roblox", "com.roblox.client", "Games", 20, true),
                        AppUsage("3", "Google Classroom", "com.google.android.apps.classroom", "Education", 25, false),
                        AppUsage("4", "Chrome", "com.android.chrome", "Browser", 14, false),
                        AppUsage("5", "Duolingo", "com.duolingo", "Education", 12, false)
                    )
                ),
                ChildDevice(
                    id = "device2",
                    name = "Ananya (Redmi)",
                    model = "Redmi Note 12",
                    age = 11,
                    iconType = "retro",
                    isOnline = true,
                    batteryPercent = 64,
                    isCharging = true,
                    lastSyncTime = "1 min ago",
                    screenLocked = true,
                    youtubeBlocked = true,
                    playStoreBlocked = true,
                    callsBlocked = true,
                    wifiBlocked = false,
                    cameraBlocked = false,
                    gamesBlocked = true,
                    screenTimeLimitHours = 1.5f,
                    screenTimeUsedMinutes = 90,
                    bedtimeEnabled = true,
                    bedtimeStart = "21:00",
                    bedtimeEnd = "07:00",
                    studyModeActive = true,
                    currentLocation = "Central Library - Safe Zone",
                    geofenceEnabled = true,
                    isInsideSafeZone = true,
                    webSafeSearchActive = true,
                    adultContentBlocked = true,
                    apps = listOf(
                        AppUsage("1", "YouTube Kids", "com.google.android.apps.youtube.kids", "Streaming", 45, true),
                        AppUsage("2", "Minecraft", "com.mojang.minecraftpe", "Games", 30, true),
                        AppUsage("3", "Khan Academy", "org.khanacademy.android", "Education", 28, false),
                        AppUsage("4", "Spotify", "com.spotify.music", "Music", 15, false)
                    )
                ),
                ChildDevice(
                    id = "device3",
                    name = "Kabir (Vivo)",
                    model = "Vivo Y20",
                    age = 8,
                    iconType = "tablet",
                    isOnline = false,
                    batteryPercent = 29,
                    isCharging = false,
                    lastSyncTime = "35 mins ago",
                    screenLocked = true,
                    youtubeBlocked = true,
                    playStoreBlocked = false,
                    callsBlocked = false,
                    wifiBlocked = true,
                    cameraBlocked = true,
                    gamesBlocked = false,
                    screenTimeLimitHours = 1.0f,
                    screenTimeUsedMinutes = 60,
                    bedtimeEnabled = false,
                    bedtimeStart = "20:30",
                    bedtimeEnd = "07:00",
                    studyModeActive = false,
                    currentLocation = "Home - Residential Safe Zone",
                    geofenceEnabled = true,
                    isInsideSafeZone = true,
                    webSafeSearchActive = true,
                    adultContentBlocked = true,
                    apps = listOf(
                        AppUsage("1", "PBS KIDS Video", "org.pbskids.video", "Education", 35, false),
                        AppUsage("2", "Subway Surfers", "com.kiloo.subwaysurf", "Games", 25, false),
                        AppUsage("3", "YouTube", "com.google.android.youtube", "Streaming", 0, true)
                    )
                )
            ),
            activityLogs = listOf(
                ActivityLog(
                    id = UUID.randomUUID().toString(),
                    deviceId = "device1",
                    deviceName = "Rahul (A34)",
                    action = "Master Control initialized securely.",
                    timestamp = "10:42 AM",
                    level = LogLevel.SUCCESS
                ),
                ActivityLog(
                    id = UUID.randomUUID().toString(),
                    deviceId = "device2",
                    deviceName = "Ananya (Redmi)",
                    action = "Study Mode activated automatically (Curfew active)",
                    timestamp = "10:15 AM",
                    level = LogLevel.INFO
                ),
                ActivityLog(
                    id = UUID.randomUUID().toString(),
                    deviceId = "device3",
                    deviceName = "Kabir (Vivo)",
                    action = "Device went offline (Battery at 29%)",
                    timestamp = "09:50 AM",
                    level = LogLevel.WARNING
                )
            )
        )
    )

    val uiState: StateFlow<ParentalShieldUiState> = _uiState.asStateFlow()

    private fun getCurrentTimeString(): String {
        val sdf = SimpleDateFormat("hh:mm:ss a", Locale.getDefault())
        return sdf.format(Date())
    }

    private fun addLog(deviceId: String, deviceName: String, action: String, level: LogLevel = LogLevel.INFO) {
        val newLog = ActivityLog(
            id = UUID.randomUUID().toString(),
            deviceId = deviceId,
            deviceName = deviceName,
            action = action,
            timestamp = getCurrentTimeString(),
            level = level
        )
        _uiState.update { current ->
            current.copy(activityLogs = listOf(newLog) + current.activityLogs)
        }
    }

    fun triggerVibration(durationMs: Long = 80) {
        try {
            val context = getApplication<Application>()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                @Suppress("DEPRECATION")
                vibrator?.vibrate(durationMs)
            }
        } catch (_: Exception) {
            // Handled safely
        }
    }

    fun setActiveDevice(deviceId: String) {
        _uiState.update { it.copy(activeDeviceId = deviceId) }
        val dev = _uiState.value.devices.find { it.id == deviceId }
        if (dev != null) {
            addLog(dev.id, dev.name, "Switched view to child device: ${dev.name}", LogLevel.INFO)
        }
    }

    fun verifyPin(pin: String): Boolean {
        return if (pin == _uiState.value.parentPin) {
            _uiState.update { it.copy(isParentAuthenticated = true) }
            triggerVibration(100)
            addLog("system", "Master Hub", "Parent PIN verified successfully", LogLevel.SUCCESS)
            true
        } else {
            triggerVibration(200)
            false
        }
    }

    fun lockParentAuth() {
        _uiState.update { it.copy(isParentAuthenticated = false) }
        triggerVibration(50)
        addLog("system", "Master Hub", "Parent session locked", LogLevel.INFO)
    }

    fun updateParentPin(oldPin: String, newPin: String): Boolean {
        if (oldPin == _uiState.value.parentPin && newPin.length == 4) {
            _uiState.update { it.copy(parentPin = newPin) }
            addLog("system", "Master Hub", "Parent Master PIN was changed", LogLevel.SUCCESS)
            triggerVibration(100)
            return true
        }
        return false
    }

    fun updateEmergencyContact(phone: String) {
        _uiState.update { it.copy(emergencyContactPhone = phone) }
        addLog("system", "Master Hub", "Emergency SOS phone updated to $phone", LogLevel.INFO)
    }

    fun toggleSingleScreenLock(deviceId: String) {
        triggerVibration()
        _uiState.update { state ->
            val updated = state.devices.map { dev ->
                if (dev.id == deviceId) {
                    val newLocked = !dev.screenLocked
                    val actionLabel = if (newLocked) "Screen Locked" else "Screen Unlocked"
                    addLog(dev.id, dev.name, actionLabel, if (newLocked) LogLevel.WARNING else LogLevel.SUCCESS)
                    dev.copy(screenLocked = newLocked)
                } else dev
            }
            state.copy(devices = updated)
        }
    }

    fun triggerGlobalPanicLock() {
        triggerVibration(300)
        _uiState.update { state ->
            val updated = state.devices.map { dev ->
                dev.copy(
                    screenLocked = true,
                    youtubeBlocked = true,
                    playStoreBlocked = true,
                    callsBlocked = true,
                    wifiBlocked = true,
                    cameraBlocked = true,
                    gamesBlocked = true
                )
            }
            state.copy(
                devices = updated,
                isGlobalPanicActive = true
            )
        }
        addLog("all", "All 3 Devices", "GLOBAL PANIC LOCK ACTIVATED: All child devices locked instantly!", LogLevel.ALERT)
    }

    fun releaseGlobalPanicLock() {
        triggerVibration(100)
        _uiState.update { state ->
            val updated = state.devices.map { dev ->
                dev.copy(
                    screenLocked = false,
                    callsBlocked = false,
                    wifiBlocked = false
                )
            }
            state.copy(
                devices = updated,
                isGlobalPanicActive = false
            )
        }
        addLog("all", "All Devices", "Global Panic released. Emergency locks removed.", LogLevel.SUCCESS)
    }

    fun updateDeviceRestriction(
        deviceId: String,
        field: String,
        value: Boolean
    ) {
        triggerVibration()
        _uiState.update { state ->
            val updated = state.devices.map { dev ->
                if (dev.id == deviceId) {
                    val modified = when (field) {
                        "youtube" -> dev.copy(youtubeBlocked = value)
                        "playStore" -> dev.copy(playStoreBlocked = value)
                        "calls" -> dev.copy(callsBlocked = value)
                        "wifi" -> dev.copy(wifiBlocked = value)
                        "camera" -> dev.copy(cameraBlocked = value)
                        "games" -> dev.copy(gamesBlocked = value)
                        "bedtime" -> dev.copy(bedtimeEnabled = value)
                        "studyMode" -> dev.copy(studyModeActive = value)
                        "geofence" -> dev.copy(geofenceEnabled = value)
                        "safeSearch" -> dev.copy(webSafeSearchActive = value)
                        "adultContent" -> dev.copy(adultContentBlocked = value)
                        else -> dev
                    }
                    val label = when (field) {
                        "youtube" -> "YouTube Streaming"
                        "playStore" -> "Play Store Downloads"
                        "calls" -> "Call Restriction"
                        "wifi" -> "Wi-Fi & Data"
                        "camera" -> "Camera & Media"
                        "games" -> "Gaming Apps"
                        "bedtime" -> "Bedtime Curfew"
                        "studyMode" -> "Study Focus Mode"
                        "geofence" -> "Geofence Perimeter"
                        "safeSearch" -> "SafeSearch Shield"
                        "adultContent" -> "Adult Web Blocker"
                        else -> field
                    }
                    val statusText = if (value) "Enabled / Blocked" else "Disabled / Allowed"
                    addLog(dev.id, dev.name, "$label set to $statusText", LogLevel.INFO)
                    modified
                } else dev
            }
            state.copy(devices = updated)
        }
    }

    fun updateScreenTimeLimit(deviceId: String, hours: Float) {
        _uiState.update { state ->
            val updated = state.devices.map { dev ->
                if (dev.id == deviceId) {
                    addLog(dev.id, dev.name, "Daily Screen Time limit set to ${hours}h", LogLevel.INFO)
                    dev.copy(screenTimeLimitHours = hours)
                } else dev
            }
            state.copy(devices = updated)
        }
    }

    fun updateBedtimeSchedule(deviceId: String, start: String, end: String) {
        _uiState.update { state ->
            val updated = state.devices.map { dev ->
                if (dev.id == deviceId) {
                    addLog(dev.id, dev.name, "Bedtime schedule set: $start to $end", LogLevel.INFO)
                    dev.copy(bedtimeStart = start, bedtimeEnd = end)
                } else dev
            }
            state.copy(devices = updated)
        }
    }

    fun toggleAppRestriction(deviceId: String, appId: String) {
        triggerVibration()
        _uiState.update { state ->
            val updated = state.devices.map { dev ->
                if (dev.id == deviceId) {
                    val updatedApps = dev.apps.map { app ->
                        if (app.id == appId) {
                            val newRestricted = !app.isRestricted
                            val statusStr = if (newRestricted) "Restricted" else "Unrestricted"
                            addLog(dev.id, dev.name, "App [${app.appName}] marked as $statusStr", LogLevel.INFO)
                            app.copy(isRestricted = newRestricted)
                        } else app
                    }
                    dev.copy(apps = updatedApps)
                } else dev
            }
            state.copy(devices = updated)
        }
    }

    fun triggerSoundAlarm(deviceId: String) {
        triggerVibration(200)
        val dev = _uiState.value.devices.find { it.id == deviceId }
        val devName = dev?.name ?: "Child Device"
        addLog(deviceId, devName, "LOUD SIREN ALARM TRIGGERED remotely on $devName", LogLevel.ALERT)

        // Play ToneGenerator alert
        viewModelScope.launch {
            try {
                val toneGen = ToneGenerator(AudioManager.STREAM_ALARM, 85)
                toneGen.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 1500)
            } catch (_: Exception) {}
        }

        _uiState.update { it.copy(isSoundAlarmRinging = true, soundAlarmCountdown = 10) }
        viewModelScope.launch {
            for (i in 9 downTo 0) {
                delay(1000)
                if (!_uiState.value.isSoundAlarmRinging) break
                _uiState.update { it.copy(soundAlarmCountdown = i) }
            }
            _uiState.update { it.copy(isSoundAlarmRinging = false) }
        }
    }

    fun stopSoundAlarm() {
        _uiState.update { it.copy(isSoundAlarmRinging = false) }
        addLog("system", "Master Hub", "Sound Alarm stopped by parent", LogLevel.INFO)
    }

    fun pingLocation(deviceId: String) {
        triggerVibration(50)
        val dev = _uiState.value.devices.find { it.id == deviceId }
        val devName = dev?.name ?: "Child Device"
        addLog(deviceId, devName, "GPS Location pinged: ${dev?.currentLocation ?: "Safe Zone"}", LogLevel.SUCCESS)
        _uiState.update { state ->
            val updated = state.devices.map { d ->
                if (d.id == deviceId) d.copy(lastSyncTime = "Just now") else d
            }
            state.copy(
                devices = updated,
                userFeedbackMessage = "Location updated for $devName"
            )
        }
    }

    fun toggleGeofenceStatus(deviceId: String) {
        triggerVibration()
        _uiState.update { state ->
            val updated = state.devices.map { dev ->
                if (dev.id == deviceId) {
                    val newInside = !dev.isInsideSafeZone
                    val statusText = if (newInside) "Returned to School Safe Zone" else "BOUNDARY ALERT: Left Safe Zone Perimeter!"
                    val level = if (newInside) LogLevel.SUCCESS else LogLevel.ALERT
                    addLog(dev.id, dev.name, statusText, level)
                    dev.copy(
                        isInsideSafeZone = newInside,
                        currentLocation = if (newInside) "Lincoln High School - Safe Zone" else "Outside Safe Zone (Oak Ave & 4th St)"
                    )
                } else dev
            }
            state.copy(devices = updated)
        }
    }

    fun addNewChildDevice(name: String, model: String, age: Int, dailyLimit: Float, iconType: String) {
        val newId = "device_" + UUID.randomUUID().toString().take(6)
        val newDevice = ChildDevice(
            id = newId,
            name = name,
            model = model,
            age = age,
            iconType = iconType,
            isOnline = true,
            batteryPercent = 100,
            screenTimeLimitHours = dailyLimit,
            screenTimeUsedMinutes = 0
        )
        _uiState.update { state ->
            state.copy(
                devices = state.devices + newDevice,
                activeDeviceId = newId
            )
        }
        addLog(newId, name, "New child device added: $name ($model)", LogLevel.SUCCESS)
        triggerVibration(100)
    }

    fun clearFeedbackMessage() {
        _uiState.update { it.copy(userFeedbackMessage = null) }
    }
}
