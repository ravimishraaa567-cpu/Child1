package com.example.model

enum class LogLevel {
    INFO,
    WARNING,
    ALERT,
    SUCCESS
}

data class AppUsage(
    val id: String,
    val appName: String,
    val packageName: String,
    val category: String, // "Streaming", "Social", "Games", "Education", "Browser"
    val minutesUsed: Int,
    val isRestricted: Boolean
)

data class ChildDevice(
    val id: String,
    val name: String,
    val model: String,
    val age: Int = 11,
    val iconType: String = "phone", // "phone", "tablet", "retro", "laptop"
    val isOnline: Boolean = true,
    val batteryPercent: Int = 85,
    val isCharging: Boolean = false,
    val lastSyncTime: String = "Just now",
    val screenLocked: Boolean = false,
    
    // Core restrictions
    val youtubeBlocked: Boolean = true,
    val playStoreBlocked: Boolean = true,
    val callsBlocked: Boolean = false,
    val wifiBlocked: Boolean = false,
    val cameraBlocked: Boolean = false,
    val gamesBlocked: Boolean = false,
    
    // Time management
    val screenTimeLimitHours: Float = 2.0f,
    val screenTimeUsedMinutes: Int = 78,
    val bedtimeEnabled: Boolean = true,
    val bedtimeStart: String = "21:30",
    val bedtimeEnd: String = "06:30",
    val studyModeActive: Boolean = false,
    
    // Geofencing & Location
    val currentLocation: String = "Lincoln High School - Safe Zone",
    val geofenceEnabled: Boolean = true,
    val latitude: Double = 37.7749,
    val longitude: Double = -122.4194,
    val isInsideSafeZone: Boolean = true,
    
    // Web protection
    val webSafeSearchActive: Boolean = true,
    val adultContentBlocked: Boolean = true,
    val blockedWebsitesCount: Int = 142,

    // App Usage breakdown
    val apps: List<AppUsage> = listOf(
        AppUsage("1", "YouTube", "com.google.android.youtube", "Streaming", 42, true),
        AppUsage("2", "Roblox", "com.roblox.client", "Games", 25, false),
        AppUsage("3", "Khan Academy", "org.khanacademy.android", "Education", 35, false),
        AppUsage("4", "Chrome", "com.android.chrome", "Browser", 18, false),
        AppUsage("5", "Duolingo", "com.duolingo", "Education", 15, false)
    )
)

data class ActivityLog(
    val id: String,
    val deviceId: String,
    val deviceName: String,
    val action: String,
    val timestamp: String,
    val level: LogLevel = LogLevel.INFO
)
