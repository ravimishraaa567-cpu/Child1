package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Translucent & Glass Theme Colors
val BackgroundDark = Color(0xFF090E17)
val BackgroundDarkSecondary = Color(0xFF0F172A)

// Glass surfaces
val GlassSurface = Color(0xCC1E293B)
val GlassSurfaceHigh = Color(0xE61E293B)
val GlassSurfaceSubtle = Color(0x801E293B)
val GlassBorder = Color(0x3364748B)
val GlassBorderHighlight = Color(0x5938BDF8)

// Neon & Minimalist Accent Colors
val NeonCyan = Color(0xFF38BDF8)
val ElectricBlue = Color(0xFF3B82F6)
val DeepBlue = Color(0xFF1D4ED8)
val EmeraldGreen = Color(0xFF10B981)
val MintEmerald = Color(0xFF34D399)
val WarningRed = Color(0xFFEF4444)
val CrimsonAlert = Color(0xFFDC2626)
val AmberAlert = Color(0xFFF59E0B)
val PurpleTech = Color(0xFFA855F7)
val VioletTech = Color(0xFF8B5CF6)

// Text tokens
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
