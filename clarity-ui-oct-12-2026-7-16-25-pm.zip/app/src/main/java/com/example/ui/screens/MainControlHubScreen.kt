package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Battery5Bar
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhoneDisabled
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.VpnLock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppUsage
import com.example.model.ChildDevice
import com.example.model.LogLevel
import com.example.ui.components.AddChildDialog
import com.example.ui.components.ChangePinDialog
import com.example.ui.components.GlassCard
import com.example.ui.components.MinimalistIconBadge
import com.example.ui.components.PinVerificationDialog
import com.example.ui.components.PulsingStatusDot
import com.example.ui.components.SoundAlarmDialog
import com.example.ui.theme.AmberAlert
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.BackgroundDarkSecondary
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassBorderHighlight
import com.example.ui.theme.GlassSurface
import com.example.ui.theme.GlassSurfaceHigh
import com.example.ui.theme.GlassSurfaceSubtle
import com.example.ui.theme.MintEmerald
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.PurpleTech
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletTech
import com.example.ui.theme.WarningRed
import com.example.viewmodel.ParentalShieldViewModel
import kotlinx.coroutines.launch

@Composable
fun MainControlHubScreen(
    viewModel: ParentalShieldViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // Dialog control states
    var showPinDialog by remember { mutableStateOf(false) }
    var pinDialogReason by remember { mutableStateOf("Parent PIN required to modify settings.") }
    var pendingAuthorizedAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var showChangePinDialog by remember { mutableStateOf(false) }
    var showAddChildDialog by remember { mutableStateOf(false) }

    // Tab state (0: Toggles, 1: Time, 2: GPS/Radar, 3: Apps & Web, 4: Logs & SOS)
    var selectedTab by remember { mutableIntStateOf(0) }

    // Active Child
    val activeDevice = uiState.devices.find { it.id == uiState.activeDeviceId }
        ?: uiState.devices.firstOrNull()

    // Helper to gate actions behind Parent PIN
    fun executeGuardedAction(reason: String, action: () -> Unit) {
        if (uiState.isParentAuthenticated) {
            action()
        } else {
            pinDialogReason = reason
            pendingAuthorizedAction = action
            showPinDialog = true
        }
    }

    LaunchedEffect(uiState.userFeedbackMessage) {
        uiState.userFeedbackMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearFeedbackMessage()
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        BackgroundDarkSecondary,
                        BackgroundDark,
                        BackgroundDarkSecondary
                    )
                )
            ),
        containerColor = Color.Transparent,
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Top Bar
            item {
                Spacer(modifier = Modifier.height(6.dp))
                HeaderSection(
                    deviceCount = uiState.devices.size,
                    isParentUnlocked = uiState.isParentAuthenticated,
                    onToggleParentAuth = {
                        if (uiState.isParentAuthenticated) {
                            viewModel.lockParentAuth()
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Parent Master Session Locked")
                            }
                        } else {
                            executeGuardedAction("Authenticate as parent to unlock all controls.") {
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar("Parent Access Granted")
                                }
                            }
                        }
                    }
                )
            }

            // Emergency Panic Bar
            item {
                GlobalPanicBar(
                    isPanicActive = uiState.isGlobalPanicActive,
                    deviceCount = uiState.devices.size,
                    onPanicClick = {
                        if (uiState.isGlobalPanicActive) {
                            executeGuardedAction("Enter PIN to release emergency panic lockdown.") {
                                viewModel.releaseGlobalPanicLock()
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar("Global Panic Lock Released")
                                }
                            }
                        } else {
                            executeGuardedAction("Emergency Global Lock: Locks all child devices immediately!") {
                                viewModel.triggerGlobalPanicLock()
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar("ALL CHILD DEVICES LOCKED IMMEDIATELY")
                                }
                            }
                        }
                    }
                )
            }

            // Child Devices Tabs Selector
            item {
                ChildDevicesSelectorRow(
                    devices = uiState.devices,
                    activeDeviceId = uiState.activeDeviceId,
                    onSelectDevice = { id -> viewModel.setActiveDevice(id) },
                    onAddChild = {
                        executeGuardedAction("Parent verification required to add child device.") {
                            showAddChildDialog = true
                        }
                    }
                )
            }

            // Active Child Overview Summary Card
            if (activeDevice != null) {
                item {
                    ActiveChildSummaryCard(
                        device = activeDevice,
                        onToggleScreenLock = {
                            executeGuardedAction("Parent PIN required to toggle screen lock.") {
                                viewModel.toggleSingleScreenLock(activeDevice.id)
                            }
                        }
                    )
                }

                // Sub-navigation Tabs
                item {
                    SubNavigationTabs(
                        selectedTab = selectedTab,
                        onTabSelect = { selectedTab = it }
                    )
                }

                // Tab Content Rendering
                when (selectedTab) {
                    0 -> {
                        item {
                            RemoteRestrictionsGrid(
                                device = activeDevice,
                                onUpdateRestriction = { field, value ->
                                    executeGuardedAction("PIN required to modify restriction.") {
                                        viewModel.updateDeviceRestriction(activeDevice.id, field, value)
                                    }
                                }
                            )
                        }
                    }
                    1 -> {
                        item {
                            TimeAndCurfewSection(
                                device = activeDevice,
                                onUpdateScreenTime = { hours ->
                                    executeGuardedAction("PIN needed to change daily screen time.") {
                                        viewModel.updateScreenTimeLimit(activeDevice.id, hours)
                                    }
                                },
                                onToggleBedtime = { enabled ->
                                    executeGuardedAction("PIN needed to toggle Bedtime curfew.") {
                                        viewModel.updateDeviceRestriction(activeDevice.id, "bedtime", enabled)
                                    }
                                },
                                onToggleStudyMode = { enabled ->
                                    executeGuardedAction("PIN needed to toggle Study mode.") {
                                        viewModel.updateDeviceRestriction(activeDevice.id, "studyMode", enabled)
                                    }
                                }
                            )
                        }
                    }
                    2 -> {
                        item {
                            LocationAndRadarSection(
                                device = activeDevice,
                                onPingLocation = {
                                    viewModel.pingLocation(activeDevice.id)
                                },
                                onTriggerAlarm = {
                                    executeGuardedAction("Confirm sending loud siren alarm.") {
                                        viewModel.triggerSoundAlarm(activeDevice.id)
                                    }
                                },
                                onToggleGeofence = {
                                    executeGuardedAction("PIN needed to adjust geofence perimeter.") {
                                        viewModel.updateDeviceRestriction(activeDevice.id, "geofence", !activeDevice.geofenceEnabled)
                                    }
                                },
                                onSimulateBreach = {
                                    viewModel.toggleGeofenceStatus(activeDevice.id)
                                }
                            )
                        }
                    }
                    3 -> {
                        item {
                            AppUsageAndWebShieldSection(
                                device = activeDevice,
                                onToggleAppRestriction = { appId ->
                                    executeGuardedAction("PIN needed to restrict app.") {
                                        viewModel.toggleAppRestriction(activeDevice.id, appId)
                                    }
                                },
                                onToggleSafeSearch = { value ->
                                    executeGuardedAction("PIN needed to change SafeSearch filter.") {
                                        viewModel.updateDeviceRestriction(activeDevice.id, "safeSearch", value)
                                    }
                                },
                                onToggleAdultBlock = { value ->
                                    executeGuardedAction("PIN needed to change Adult Web Blocker.") {
                                        viewModel.updateDeviceRestriction(activeDevice.id, "adultContent", value)
                                    }
                                }
                            )
                        }
                    }
                    4 -> {
                        item {
                            LogsAndEmergencySection(
                                logs = uiState.activityLogs,
                                emergencyContact = uiState.emergencyContactPhone,
                                onTestSos = {
                                    val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                                        data = Uri.parse("tel:${uiState.emergencyContactPhone}")
                                    }
                                    context.startActivity(dialIntent)
                                },
                                onChangePinClick = {
                                    executeGuardedAction("Authenticate before updating Parent PIN.") {
                                        showChangePinDialog = true
                                    }
                                }
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Modal dialogs
    if (showPinDialog) {
        PinVerificationDialog(
            actionDescription = pinDialogReason,
            onDismiss = {
                showPinDialog = false
                pendingAuthorizedAction = null
            },
            onSuccess = {
                showPinDialog = false
                pendingAuthorizedAction?.invoke()
                pendingAuthorizedAction = null
            },
            onVerifyPin = { pin -> viewModel.verifyPin(pin) }
        )
    }

    if (showChangePinDialog) {
        ChangePinDialog(
            onDismiss = { showChangePinDialog = false },
            onSaveNewPin = { oldP, newP -> viewModel.updateParentPin(oldP, newP) }
        )
    }

    if (showAddChildDialog) {
        AddChildDialog(
            onDismiss = { showAddChildDialog = false },
            onAddChild = { name, model, age, limit, iconType ->
                viewModel.addNewChildDevice(name, model, age, limit, iconType)
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Child Device Connected: $name")
                }
            }
        )
    }

    if (uiState.isSoundAlarmRinging) {
        SoundAlarmDialog(
            countdown = uiState.soundAlarmCountdown,
            onStopAlarm = { viewModel.stopSoundAlarm() }
        )
    }
}

// ---------------------------------------------------------------------------
// Screen Sections
// ---------------------------------------------------------------------------

@Composable
private fun HeaderSection(
    deviceCount: Int,
    isParentUnlocked: Boolean,
    onToggleParentAuth: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MinimalistIconBadge(
                icon = Icons.Default.Shield,
                contentDescription = "Shield",
                accentColor = NeonCyan,
                containerSize = 44.dp,
                iconSize = 22.dp
            )
            Column {
                Text(
                    text = "Parental Shield",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    letterSpacing = 0.3.sp
                )
                Text(
                    text = "Master Control ($deviceCount Children)",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }
        }

        // Parent Authentication Toggle Button
        val buttonBg = if (isParentUnlocked) EmeraldGreen.copy(alpha = 0.2f) else GlassSurfaceSubtle
        val buttonBorder = if (isParentUnlocked) EmeraldGreen.copy(alpha = 0.5f) else GlassBorder
        val buttonText = if (isParentUnlocked) "Parent Unlocked" else "Parent Locked"
        val buttonIcon = if (isParentUnlocked) Icons.Default.LockOpen else Icons.Default.Lock
        val iconColor = if (isParentUnlocked) EmeraldGreen else AmberAlert

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(buttonBg)
                .border(1.dp, buttonBorder, RoundedCornerShape(14.dp))
                .clickable(onClick = onToggleParentAuth)
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .testTag("parent_auth_toggle_btn")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = buttonIcon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = buttonText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isParentUnlocked) EmeraldGreen else TextSecondary
                )
            }
        }
    }
}

@Composable
private fun GlobalPanicBar(
    isPanicActive: Boolean,
    deviceCount: Int,
    onPanicClick: () -> Unit
) {
    val borderColor = if (isPanicActive) CrimsonAlert else Color(0x66EF4444)
    val containerBg = if (isPanicActive) Color(0x33DC2626) else GlassSurface

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = containerBg,
        borderColor = borderColor,
        borderWidth = if (isPanicActive) 2.dp else 1.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(WarningRed.copy(alpha = 0.2f))
                            .border(1.dp, WarningRed.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (isPanicActive) "ACTIVE LOCKDOWN" else "EMERGENCY ACTION",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = WarningRed,
                            letterSpacing = 0.8.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Global Child Lock",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = if (isPanicActive) "All $deviceCount devices are restricted" else "Instantly lock all $deviceCount connected child phones",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Button(
                onClick = onPanicClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isPanicActive) EmeraldGreen else CrimsonAlert
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("panic_lock_all_btn")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = if (isPanicActive) Icons.Default.LockOpen else Icons.Default.PowerSettingsNew,
                        contentDescription = "Panic",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (isPanicActive) "UNLOCK ALL" else "LOCK ALL ($deviceCount)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun ChildDevicesSelectorRow(
    devices: List<ChildDevice>,
    activeDeviceId: String,
    onSelectDevice: (String) -> Unit,
    onAddChild: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "SELECT CHILD DEVICE TO MANAGE",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted,
            letterSpacing = 1.sp
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(devices) { dev ->
                val isSelected = dev.id == activeDeviceId
                val cardBg = if (isSelected) ElectricBlue.copy(alpha = 0.22f) else GlassSurfaceSubtle
                val border = if (isSelected) NeonCyan else GlassBorder

                Box(
                    modifier = Modifier
                        .width(116.dp)
                        .height(82.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(cardBg)
                        .border(1.dp, border, RoundedCornerShape(16.dp))
                        .clickable { onSelectDevice(dev.id) }
                        .padding(10.dp)
                        .testTag("device_tab_${dev.id}")
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = when (dev.iconType) {
                                    "tablet" -> Icons.Default.Apps
                                    else -> Icons.Default.Smartphone
                                },
                                contentDescription = null,
                                tint = if (isSelected) NeonCyan else TextSecondary,
                                modifier = Modifier.size(17.dp)
                            )
                            PulsingStatusDot(
                                color = if (dev.isOnline) MintEmerald else TextMuted,
                                size = 7.dp,
                                isPulsing = dev.isOnline
                            )
                        }

                        Column {
                            Text(
                                text = dev.name,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) TextPrimary else TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Text(
                                    text = "${dev.batteryPercent}% Bat",
                                    fontSize = 10.sp,
                                    color = TextMuted,
                                    fontFamily = FontFamily.Monospace
                                )
                                if (dev.screenLocked) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "Locked",
                                        tint = WarningRed,
                                        modifier = Modifier.size(10.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Add Child Card
            item {
                Box(
                    modifier = Modifier
                        .width(80.dp)
                        .height(82.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(GlassSurfaceSubtle)
                        .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
                        .clickable(onClick = onAddChild)
                        .padding(10.dp)
                        .testTag("add_child_tab_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add Child",
                            tint = NeonCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "+ Add",
                            fontSize = 11.sp,
                            color = NeonCyan,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ActiveChildSummaryCard(
    device: ChildDevice,
    onToggleScreenLock: () -> Unit
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = GlassSurface,
        borderColor = GlassBorder
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MinimalistIconBadge(
                        icon = Icons.Default.Smartphone,
                        contentDescription = "Device",
                        accentColor = ElectricBlue,
                        containerSize = 48.dp,
                        iconSize = 24.dp
                    )
                    Column {
                        Text(
                            text = device.name,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "${device.model} • Age ${device.age}",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    // Online / Offline chip
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (device.isOnline) MintEmerald.copy(alpha = 0.18f)
                                else Color(0x33475569)
                            )
                            .border(
                                1.dp,
                                if (device.isOnline) MintEmerald.copy(alpha = 0.4f)
                                else GlassBorder,
                                RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            PulsingStatusDot(
                                color = if (device.isOnline) MintEmerald else TextMuted,
                                size = 6.dp,
                                isPulsing = device.isOnline
                            )
                            Text(
                                text = if (device.isOnline) "Online" else "Offline",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (device.isOnline) MintEmerald else TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (device.isCharging) Icons.Default.BatteryChargingFull
                            else if (device.batteryPercent < 20) Icons.Default.BatteryAlert
                            else Icons.Default.Battery5Bar,
                            contentDescription = "Battery",
                            tint = if (device.batteryPercent < 20) WarningRed else TextSecondary,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "${device.batteryPercent}%",
                            fontSize = 11.sp,
                            color = TextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // Screen Lock Status & Action Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0x33090E17))
                    .border(1.dp, GlassBorder, RoundedCornerShape(14.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Device Screen Lock Status:",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                        Text(
                            text = if (device.screenLocked) "Display is completely blocked" else "Display unlocked and active",
                            fontSize = 10.sp,
                            color = if (device.screenLocked) WarningRed else MintEmerald
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (device.screenLocked) WarningRed.copy(alpha = 0.2f)
                                else MintEmerald.copy(alpha = 0.2f)
                            )
                            .border(
                                1.dp,
                                if (device.screenLocked) WarningRed.copy(alpha = 0.4f)
                                else MintEmerald.copy(alpha = 0.4f),
                                RoundedCornerShape(10.dp)
                            )
                            .clickable(onClick = onToggleScreenLock)
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .testTag("device_screen_lock_btn")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = if (device.screenLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                                contentDescription = null,
                                tint = if (device.screenLocked) WarningRed else MintEmerald,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = if (device.screenLocked) "Screen Locked" else "Screen Unlocked",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (device.screenLocked) WarningRed else MintEmerald
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SubNavigationTabs(
    selectedTab: Int,
    onTabSelect: (Int) -> Unit
) {
    val tabTitles = listOf(
        "Restrictions",
        "Curfew & Time",
        "GPS & Radar",
        "Apps & Web",
        "Logs & SOS"
    )

    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(tabTitles.indices.toList()) { index ->
            val isSelected = selectedTab == index
            val bg = if (isSelected) NeonCyan.copy(alpha = 0.2f) else GlassSurfaceSubtle
            val border = if (isSelected) NeonCyan.copy(alpha = 0.6f) else GlassBorder

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(bg)
                    .border(1.dp, border, RoundedCornerShape(12.dp))
                    .clickable { onTabSelect(index) }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
                    .testTag("sub_nav_tab_$index")
            ) {
                Text(
                    text = tabTitles[index],
                    fontSize = 11.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    color = if (isSelected) NeonCyan else TextSecondary
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Tab 0: Remote Restrictions
// ---------------------------------------------------------------------------

@Composable
private fun RemoteRestrictionsGrid(
    device: ChildDevice,
    onUpdateRestriction: (field: String, value: Boolean) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "REMOTE RESTRICTION TOGGLES",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted,
            letterSpacing = 1.sp
        )

        RestrictionToggleItem(
            icon = Icons.Default.PlayCircleOutline,
            iconColor = WarningRed,
            title = "YouTube Restriction",
            subtitle = "Block video streaming app & player",
            isChecked = device.youtubeBlocked,
            onCheckedChange = { onUpdateRestriction("youtube", it) },
            tag = "toggle_youtube"
        )

        RestrictionToggleItem(
            icon = Icons.Default.Download,
            iconColor = MintEmerald,
            title = "Play Store Downloads",
            subtitle = "Block installing new apps & purchases",
            isChecked = device.playStoreBlocked,
            onCheckedChange = { onUpdateRestriction("playStore", it) },
            tag = "toggle_play_store"
        )

        RestrictionToggleItem(
            icon = Icons.Default.PhoneDisabled,
            iconColor = AmberAlert,
            title = "Call Restrictions",
            subtitle = "Lock non-emergency dialer & incoming unknown",
            isChecked = device.callsBlocked,
            onCheckedChange = { onUpdateRestriction("calls", it) },
            tag = "toggle_calls"
        )

        RestrictionToggleItem(
            icon = Icons.Default.Wifi,
            iconColor = NeonCyan,
            title = "Internet / Wi-Fi Access",
            subtitle = "Disable wireless & mobile network connection",
            isChecked = device.wifiBlocked,
            onCheckedChange = { onUpdateRestriction("wifi", it) },
            tag = "toggle_wifi"
        )

        RestrictionToggleItem(
            icon = Icons.Default.VideocamOff,
            iconColor = PurpleTech,
            title = "Camera & Media Access",
            subtitle = "Lock camera shutter & photo gallery sharing",
            isChecked = device.cameraBlocked,
            onCheckedChange = { onUpdateRestriction("camera", it) },
            tag = "toggle_camera"
        )

        RestrictionToggleItem(
            icon = Icons.Default.SportsEsports,
            iconColor = VioletTech,
            title = "Gaming Apps Lock",
            subtitle = "Restrict Roblox, Minecraft, & online multiplayer",
            isChecked = device.gamesBlocked,
            onCheckedChange = { onUpdateRestriction("games", it) },
            tag = "toggle_games"
        )
    }
}

@Composable
private fun RestrictionToggleItem(
    icon: ImageVector,
    iconColor: Color,
    title: String,
    subtitle: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    tag: String
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = GlassSurface,
        borderColor = GlassBorder
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                MinimalistIconBadge(
                    icon = icon,
                    contentDescription = title,
                    accentColor = iconColor
                )
                Column {
                    Text(
                        text = title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }

            Switch(
                checked = isChecked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = ElectricBlue,
                    uncheckedThumbColor = TextMuted,
                    uncheckedTrackColor = Color(0x331E293B)
                ),
                modifier = Modifier.testTag(tag)
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Tab 1: Time & Curfew
// ---------------------------------------------------------------------------

@Composable
private fun TimeAndCurfewSection(
    device: ChildDevice,
    onUpdateScreenTime: (Float) -> Unit,
    onToggleBedtime: (Boolean) -> Unit,
    onToggleStudyMode: (Boolean) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Daily Screen Time Slider Card
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = GlassSurface,
            borderColor = GlassBorder
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.HourglassBottom,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "Daily Screen Allowance",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(NeonCyan.copy(alpha = 0.15f))
                            .border(1.dp, NeonCyan.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "${device.screenTimeLimitHours}h / Day",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonCyan
                        )
                    }
                }

                // Progress Bar of Time Used
                val progress = (device.screenTimeUsedMinutes / (device.screenTimeLimitHours * 60f)).coerceIn(0f, 1f)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Used: ${device.screenTimeUsedMinutes} mins",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                        val remainingMins = ((device.screenTimeLimitHours * 60) - device.screenTimeUsedMinutes).toInt().coerceAtLeast(0)
                        Text(
                            text = "Remaining: $remainingMins mins",
                            fontSize = 11.sp,
                            color = if (remainingMins < 15) WarningRed else MintEmerald
                        )
                    }

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (progress > 0.9f) WarningRed else ElectricBlue,
                        trackColor = Color(0x33475569)
                    )
                }

                // Slider
                Slider(
                    value = device.screenTimeLimitHours,
                    onValueChange = onUpdateScreenTime,
                    valueRange = 0.5f..6.0f,
                    steps = 10,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyan,
                        activeTrackColor = NeonCyan,
                        inactiveTrackColor = Color(0x3364748B)
                    ),
                    modifier = Modifier.testTag("screen_time_slider")
                )

                // Quick Presets
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val presets = listOf(1.0f, 1.5f, 2.0f, 3.0f, 4.0f)
                    for (preset in presets) {
                        val isCurrent = device.screenTimeLimitHours == preset
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isCurrent) NeonCyan.copy(alpha = 0.2f) else Color(0x221E293B))
                                .border(1.dp, if (isCurrent) NeonCyan else GlassBorder, RoundedCornerShape(8.dp))
                                .clickable { onUpdateScreenTime(preset) }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${preset}h",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isCurrent) NeonCyan else TextSecondary
                            )
                        }
                    }
                }
            }
        }

        // Bedtime Curfew Schedule Card
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = GlassSurface,
            borderColor = GlassBorder
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MinimalistIconBadge(
                            icon = Icons.Default.Nightlight,
                            contentDescription = "Bedtime",
                            accentColor = VioletTech
                        )
                        Column {
                            Text(
                                text = "Nightly Bedtime Curfew",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Auto-locks device from ${device.bedtimeStart} to ${device.bedtimeEnd}",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    Switch(
                        checked = device.bedtimeEnabled,
                        onCheckedChange = onToggleBedtime,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = VioletTech
                        ),
                        modifier = Modifier.testTag("toggle_bedtime")
                    )
                }
            }
        }

        // Study Focus Mode Card
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = GlassSurface,
            borderColor = GlassBorder
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    MinimalistIconBadge(
                        icon = Icons.Default.School,
                        contentDescription = "Study",
                        accentColor = EmeraldGreen
                    )
                    Column {
                        Text(
                            text = "Study Focus Mode",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Silences distractions, only allows learning apps",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                Switch(
                    checked = device.studyModeActive,
                    onCheckedChange = onToggleStudyMode,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = EmeraldGreen
                    ),
                    modifier = Modifier.testTag("toggle_study_mode")
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Tab 2: GPS & Radar
// ---------------------------------------------------------------------------

@Composable
private fun LocationAndRadarSection(
    device: ChildDevice,
    onPingLocation: () -> Unit,
    onTriggerAlarm: () -> Unit,
    onToggleGeofence: () -> Unit,
    onSimulateBreach: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Live GPS Card
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = GlassSurface,
            borderColor = GlassBorder
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "Live GPS Telemetry",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (device.isInsideSafeZone) MintEmerald.copy(alpha = 0.15f) else WarningRed.copy(alpha = 0.2f))
                            .border(1.dp, if (device.isInsideSafeZone) MintEmerald.copy(alpha = 0.35f) else WarningRed.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = if (device.isInsideSafeZone) "SAFE ZONE" else "BREACH ALERT",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (device.isInsideSafeZone) MintEmerald else WarningRed
                        )
                    }
                }

                // Location Box with Coordinates
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x33090E17))
                        .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = device.currentLocation,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Coordinates: ${device.latitude}, ${device.longitude} • Last Ping: ${device.lastSyncTime}",
                            fontSize = 10.sp,
                            color = TextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onPingLocation,
                        border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorder),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f).testTag("ping_location_btn")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Ping",
                                tint = NeonCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Text("Ping GPS", fontSize = 11.sp, color = TextPrimary)
                        }
                    }

                    OutlinedButton(
                        onClick = onSimulateBreach,
                        border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorder),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f).testTag("simulate_breach_btn")
                    ) {
                        Text(
                            text = if (device.isInsideSafeZone) "Test Breach" else "Return Safe",
                            fontSize = 11.sp,
                            color = if (device.isInsideSafeZone) WarningRed else MintEmerald
                        )
                    }
                }
            }
        }

        // Sound Siren Finder Card
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = GlassSurface,
            borderColor = GlassBorder
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    MinimalistIconBadge(
                        icon = Icons.Default.NotificationsActive,
                        contentDescription = "Siren",
                        accentColor = CrimsonAlert
                    )
                    Column {
                        Text(
                            text = "Find Device (Siren Ring)",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Remotely sound max volume siren to find phone",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                Button(
                    onClick = onTriggerAlarm,
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("trigger_siren_btn")
                ) {
                    Text("Ring Siren", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Tab 3: Apps & Web
// ---------------------------------------------------------------------------

@Composable
private fun AppUsageAndWebShieldSection(
    device: ChildDevice,
    onToggleAppRestriction: (appId: String) -> Unit,
    onToggleSafeSearch: (Boolean) -> Unit,
    onToggleAdultBlock: (Boolean) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // App Category Usage & Per-App Restrictions
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = GlassSurface,
            borderColor = GlassBorder
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Apps,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "App Breakdown & Locks",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    Text(
                        text = "${device.apps.size} Tracked Apps",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }

                // List of tracked apps
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (app in device.apps) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0x33090E17))
                                .border(1.dp, GlassBorder, RoundedCornerShape(10.dp))
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = app.appName,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "${app.category} • ${app.minutesUsed} mins today",
                                    fontSize = 10.sp,
                                    color = TextSecondary
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (app.isRestricted) WarningRed.copy(alpha = 0.2f)
                                        else MintEmerald.copy(alpha = 0.2f)
                                    )
                                    .border(
                                        1.dp,
                                        if (app.isRestricted) WarningRed.copy(alpha = 0.4f)
                                        else MintEmerald.copy(alpha = 0.4f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { onToggleAppRestriction(app.id) }
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                                    .testTag("app_restrict_toggle_${app.id}")
                            ) {
                                Text(
                                    text = if (app.isRestricted) "Blocked" else "Allowed",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (app.isRestricted) WarningRed else MintEmerald
                                )
                            }
                        }
                    }
                }
            }
        }

        // Web Shield Card
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = GlassSurface,
            borderColor = GlassBorder
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Public,
                        contentDescription = null,
                        tint = ElectricBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Web Content & SafeSearch Shield",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Strict SafeSearch",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Filters explicit results on Google and Bing",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                    Switch(
                        checked = device.webSafeSearchActive,
                        onCheckedChange = onToggleSafeSearch,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = ElectricBlue
                        ),
                        modifier = Modifier.testTag("toggle_safe_search")
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Adult Web Blocker",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Blacklists 140+ adult and gambling domains",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                    Switch(
                        checked = device.adultContentBlocked,
                        onCheckedChange = onToggleAdultBlock,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = ElectricBlue
                        ),
                        modifier = Modifier.testTag("toggle_adult_block")
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Tab 4: Logs & SOS
// ---------------------------------------------------------------------------

@Composable
private fun LogsAndEmergencySection(
    logs: List<com.example.model.ActivityLog>,
    emergencyContact: String,
    onTestSos: () -> Unit,
    onChangePinClick: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Emergency & PIN actions
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = GlassSurface,
            borderColor = GlassBorder
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "PARENT EMERGENCY & PIN CONFIG",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMuted,
                    letterSpacing = 1.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onTestSos,
                        colors = ButtonDefaults.buttonColors(containerColor = WarningRed.copy(alpha = 0.25f)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, WarningRed.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).testTag("sos_test_btn")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Phone,
                                contentDescription = "SOS",
                                tint = WarningRed,
                                modifier = Modifier.size(16.dp)
                            )
                            Text("Test SOS Call", fontSize = 11.sp, color = WarningRed, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = onChangePinClick,
                        colors = ButtonDefaults.buttonColors(containerColor = GlassSurfaceSubtle),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorder),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).testTag("open_change_pin_btn")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = "PIN",
                                tint = AmberAlert,
                                modifier = Modifier.size(16.dp)
                            )
                            Text("Change PIN", fontSize = 11.sp, color = TextPrimary)
                        }
                    }
                }
            }
        }

        // Activity Logs List
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = GlassSurface,
            borderColor = GlassBorder
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Live Multi-Device Activity Log",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x33090E17))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${logs.size} Events",
                            fontSize = 10.sp,
                            color = TextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (log in logs.take(15)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0x33090E17))
                                .border(1.dp, GlassBorder, RoundedCornerShape(10.dp))
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when (log.level) {
                                                LogLevel.ALERT -> CrimsonAlert
                                                LogLevel.WARNING -> AmberAlert
                                                LogLevel.SUCCESS -> MintEmerald
                                                LogLevel.INFO -> NeonCyan
                                            }
                                        )
                                )
                                Column {
                                    Text(
                                        text = log.action,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = log.deviceName,
                                        fontSize = 10.sp,
                                        color = TextSecondary
                                    )
                                }
                            }

                            Text(
                                text = log.timestamp,
                                fontSize = 9.sp,
                                color = TextMuted,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}
